﻿using System;

namespace HelloWorld
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("HELLO!");
            Console.WriteLine("92000103073-Raj Chhadia");
            Console.Read();
        }
    }
}