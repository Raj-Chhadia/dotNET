﻿
namespace WindowsForms_Calc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.num_0 = new System.Windows.Forms.Button();
            this.point = new System.Windows.Forms.Button();
            this.num_3 = new System.Windows.Forms.Button();
            this.num_2 = new System.Windows.Forms.Button();
            this.num_1 = new System.Windows.Forms.Button();
            this.num_5 = new System.Windows.Forms.Button();
            this.num_4 = new System.Windows.Forms.Button();
            this.num_9 = new System.Windows.Forms.Button();
            this.num_8 = new System.Windows.Forms.Button();
            this.num_7 = new System.Windows.Forms.Button();
            this.divide = new System.Windows.Forms.Button();
            this.multiply = new System.Windows.Forms.Button();
            this.add = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.num_6 = new System.Windows.Forms.Button();
            this.equals = new System.Windows.Forms.Button();
            this.subtract = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // num_0
            // 
            this.num_0.Location = new System.Drawing.Point(43, 362);
            this.num_0.Name = "num_0";
            this.num_0.Size = new System.Drawing.Size(131, 49);
            this.num_0.TabIndex = 1;
            this.num_0.Text = "0";
            this.num_0.UseVisualStyleBackColor = true;
            this.num_0.Click += new System.EventHandler(this.num_0_Click);
            // 
            // point
            // 
            this.point.Location = new System.Drawing.Point(189, 362);
            this.point.Name = "point";
            this.point.Size = new System.Drawing.Size(57, 49);
            this.point.TabIndex = 2;
            this.point.Text = ".";
            this.point.UseVisualStyleBackColor = true;
            this.point.Click += new System.EventHandler(this.point_Click);
            // 
            // num_3
            // 
            this.num_3.Location = new System.Drawing.Point(189, 291);
            this.num_3.Name = "num_3";
            this.num_3.Size = new System.Drawing.Size(57, 49);
            this.num_3.TabIndex = 5;
            this.num_3.Text = "3";
            this.num_3.UseVisualStyleBackColor = true;
            this.num_3.Click += new System.EventHandler(this.num_3_Click);
            // 
            // num_2
            // 
            this.num_2.Location = new System.Drawing.Point(117, 291);
            this.num_2.Name = "num_2";
            this.num_2.Size = new System.Drawing.Size(57, 49);
            this.num_2.TabIndex = 4;
            this.num_2.Text = "2";
            this.num_2.UseVisualStyleBackColor = true;
            this.num_2.Click += new System.EventHandler(this.num_2_Click);
            // 
            // num_1
            // 
            this.num_1.Location = new System.Drawing.Point(43, 291);
            this.num_1.Name = "num_1";
            this.num_1.Size = new System.Drawing.Size(57, 49);
            this.num_1.TabIndex = 3;
            this.num_1.Text = "1";
            this.num_1.UseVisualStyleBackColor = true;
            this.num_1.Click += new System.EventHandler(this.num_1_Click);
            // 
            // num_5
            // 
            this.num_5.Location = new System.Drawing.Point(117, 223);
            this.num_5.Name = "num_5";
            this.num_5.Size = new System.Drawing.Size(57, 49);
            this.num_5.TabIndex = 7;
            this.num_5.Text = "5";
            this.num_5.UseVisualStyleBackColor = true;
            this.num_5.Click += new System.EventHandler(this.num_5_Click);
            // 
            // num_4
            // 
            this.num_4.Location = new System.Drawing.Point(43, 223);
            this.num_4.Name = "num_4";
            this.num_4.Size = new System.Drawing.Size(57, 49);
            this.num_4.TabIndex = 6;
            this.num_4.Text = "4";
            this.num_4.UseVisualStyleBackColor = true;
            this.num_4.Click += new System.EventHandler(this.num_4_Click);
            // 
            // num_9
            // 
            this.num_9.Location = new System.Drawing.Point(189, 155);
            this.num_9.Name = "num_9";
            this.num_9.Size = new System.Drawing.Size(57, 49);
            this.num_9.TabIndex = 11;
            this.num_9.Text = "9";
            this.num_9.UseVisualStyleBackColor = true;
            this.num_9.Click += new System.EventHandler(this.num_9_Click);
            // 
            // num_8
            // 
            this.num_8.Location = new System.Drawing.Point(117, 155);
            this.num_8.Name = "num_8";
            this.num_8.Size = new System.Drawing.Size(57, 49);
            this.num_8.TabIndex = 10;
            this.num_8.Text = "8";
            this.num_8.UseVisualStyleBackColor = true;
            this.num_8.Click += new System.EventHandler(this.num_8_Click);
            // 
            // num_7
            // 
            this.num_7.Location = new System.Drawing.Point(43, 155);
            this.num_7.Name = "num_7";
            this.num_7.Size = new System.Drawing.Size(57, 49);
            this.num_7.TabIndex = 9;
            this.num_7.Text = "7";
            this.num_7.UseVisualStyleBackColor = true;
            this.num_7.Click += new System.EventHandler(this.num_7_Click);
            // 
            // divide
            // 
            this.divide.Location = new System.Drawing.Point(266, 362);
            this.divide.Name = "divide";
            this.divide.Size = new System.Drawing.Size(57, 49);
            this.divide.TabIndex = 12;
            this.divide.Text = "/";
            this.divide.UseVisualStyleBackColor = true;
            this.divide.Click += new System.EventHandler(this.divide_Click);
            // 
            // multiply
            // 
            this.multiply.Location = new System.Drawing.Point(266, 291);
            this.multiply.Name = "multiply";
            this.multiply.Size = new System.Drawing.Size(57, 49);
            this.multiply.TabIndex = 13;
            this.multiply.Text = "*";
            this.multiply.UseVisualStyleBackColor = true;
            this.multiply.Click += new System.EventHandler(this.multiply_Click);
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(266, 155);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(57, 49);
            this.add.TabIndex = 15;
            this.add.Text = "+";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(43, 100);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(131, 49);
            this.clear.TabIndex = 16;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(43, 25);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(280, 63);
            this.textBox1.TabIndex = 17;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
        
            // 
            // num_6
            // 
            this.num_6.Location = new System.Drawing.Point(189, 223);
            this.num_6.Name = "num_6";
            this.num_6.Size = new System.Drawing.Size(57, 49);
            this.num_6.TabIndex = 18;
            this.num_6.Text = "6";
            this.num_6.UseVisualStyleBackColor = true;
            this.num_6.Click += new System.EventHandler(this.num_6_Click);
            // 
            // equals
            // 
            this.equals.Location = new System.Drawing.Point(189, 100);
            this.equals.Name = "equals";
            this.equals.Size = new System.Drawing.Size(131, 49);
            this.equals.TabIndex = 19;
            this.equals.Text = "=";
            this.equals.UseVisualStyleBackColor = true;
            this.equals.Click += new System.EventHandler(this.equals_Click);
            // 
            // subtract
            // 
            this.subtract.Location = new System.Drawing.Point(266, 223);
            this.subtract.Name = "subtract";
            this.subtract.Size = new System.Drawing.Size(57, 49);
            this.subtract.TabIndex = 20;
            this.subtract.Text = "-";
            this.subtract.UseVisualStyleBackColor = true;
            this.subtract.Click += new System.EventHandler(this.subtract_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 450);
            this.Controls.Add(this.subtract);
            this.Controls.Add(this.equals);
            this.Controls.Add(this.num_6);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.add);
            this.Controls.Add(this.multiply);
            this.Controls.Add(this.divide);
            this.Controls.Add(this.num_9);
            this.Controls.Add(this.num_8);
            this.Controls.Add(this.num_7);
            this.Controls.Add(this.num_5);
            this.Controls.Add(this.num_4);
            this.Controls.Add(this.num_3);
            this.Controls.Add(this.num_2);
            this.Controls.Add(this.num_1);
            this.Controls.Add(this.point);
            this.Controls.Add(this.num_0);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button num_0;
        private System.Windows.Forms.Button point;
        private System.Windows.Forms.Button num_3;
        private System.Windows.Forms.Button num_2;
        private System.Windows.Forms.Button num_1;
        private System.Windows.Forms.Button num_5;
        private System.Windows.Forms.Button num_4;
        private System.Windows.Forms.Button num_9;
        private System.Windows.Forms.Button num_8;
        private System.Windows.Forms.Button num_7;
        private System.Windows.Forms.Button divide;
        private System.Windows.Forms.Button multiply;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button num_6;
        private System.Windows.Forms.Button equals;
        private System.Windows.Forms.Button subtract;
    }
}

