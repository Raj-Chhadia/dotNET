﻿select * from student
